create definer = root@localhost trigger supp_lig
    after delete
    on lignedecommande
    for each row
BEGIN
		  DECLARE id_vieu INT;
        DECLARE sous double;
        DECLARE reduc INT;
        SET id_vieu = old.id_commande;
        SET reduc = (SELECT (remise/100) FROM commande WHERE id=id_vieu);
        SET sous = (SELECT SUM(prix*quantite)*(1-reduc) FROM lignedecommande WHERE id_commande = id_vieu);
        UPDATE commande SET total=(total-sous) WHERE id=id_vieu;
END;

